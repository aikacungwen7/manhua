// script_external.js
document.write('<script type="text/javascript" dazedarticulate.com/f6/06/4d/f6064d13465eb067aedc319235a586f0.js"></script>');
